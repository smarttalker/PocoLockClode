package com.example.phonelock

import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaRecorder
import android.os.SystemClock
import android.telephony.TelephonyManager
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.util.concurrent.CopyOnWriteArrayList
import kotlin.math.sqrt

/** Что показывать на экране про микрофон. */
object AudioStatus {
    var level by mutableStateOf(0f)
    var text by mutableStateOf("")
}

/**
 * Звук: AudioRecord -> AAC -> дорожка в MP4 выбранной камеры.
 * Детектор: если микрофон выдаёт подряд только нули (так делает система во время звонка),
 * это записывается в журнал. Во время звонка приложение автоматически пробует другие источники звука.
 */
class AudioPipeline(private val prefSource: Int) {

    private val writers = CopyOnWriteArrayList<SegmentWriter>()
    @Volatile private var outFormat: MediaFormat? = null
    @Volatile private var running = false
    @Volatile private var failed = false
    private var thread: Thread? = null

    /** Подключает файл-писатель камеры, в которую пойдёт звук (можно подключить несколько). */
    fun attach(w: SegmentWriter) {
        if (failed) return
        writers.add(w)
        w.expectAudio()
        outFormat?.let { w.setAudioFormat(it) }
    }

    fun start() {
        running = true
        thread = Thread({ runLoop() }, "audio").also { it.start() }
    }

    fun stopBlocking() {
        running = false
        try { thread?.join(4000) } catch (_: Exception) {}
    }

    private fun fail(msg: String) {
        failed = true
        RecLog.log(msg)
        writers.forEach { it.dropAudio() }
        AudioStatus.text = "Микрофон: нет звука"
    }

    private fun openRecord(idx: Int): AudioRecord? {
        val src = SOURCES[idx].first
        return try {
            val minBuf = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val r = AudioRecord.Builder()
                .setAudioSource(src)
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(RATE)
                        .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                        .build()
                )
                .setBufferSizeInBytes(maxOf(minBuf * 2, 16384))
                .build()
            if (r.state != AudioRecord.STATE_INITIALIZED) {
                r.release()
                RecLog.log("Микрофон: источник «${SOURCES[idx].second}» не открылся")
                null
            } else {
                r
            }
        } catch (e: Exception) {
            RecLog.log("Микрофон: источник «${SOURCES[idx].second}» не открылся: ${e.message}")
            null
        }
    }

    private fun runLoop() {
        var enc: MediaCodec? = null
        var rec: AudioRecord? = null
        var lastPts = 0L
        try {
            val fmt = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, RATE, 1).apply {
                setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                setInteger(MediaFormat.KEY_BIT_RATE, 96_000)
                setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
            }
            enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
            enc.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            enc.start()

            var srcIdx = prefSource.coerceIn(0, SOURCES.size - 1)
            var cur: AudioRecord = openRecord(srcIdx) ?: run {
                fail("Микрофон: не удалось открыть")
                return
            }
            rec = cur
            cur.startRecording()
            if (cur.recordingState != AudioRecord.RECORDSTATE_RECORDING) {
                fail("Микрофон: запись не началась")
                return
            }
            RecLog.log("Микрофон: пишу, источник «${SOURCES[srcIdx].second}»")
            AudioStatus.text = "Микрофон: работает"

            val buf = ByteArray(4096)
            var baseUs = -1L
            var total = 0L
            var zeroMs = 0L
            var silent = false
            var silentAt = 0L
            var prevCall = TelephonyManager.CALL_STATE_IDLE
            val tried = mutableSetOf<Int>()
            var exhausted = false
            var lastUi = 0L

            while (running) {
                val n = cur.read(buf, 0, buf.size)
                if (n < 0) {
                    RecLog.log("Микрофон: ошибка чтения ($n), перезапускаю")
                    cur.release()
                    val again = openRecord(srcIdx)
                    if (again == null) {
                        fail("Микрофон: не удалось открыть заново")
                        return
                    }
                    cur = again
                    rec = again
                    again.startRecording()
                    baseUs = -1L
                    continue
                }
                if (n == 0) continue

                val nowUs = SystemClock.elapsedRealtimeNanos() / 1000
                val samplesInChunk = n / 2
                val chunkUs = samplesInChunk * 1_000_000L / RATE
                if (baseUs < 0) {
                    baseUs = nowUs - chunkUs
                    total = 0
                } else {
                    val expected = baseUs + total * 1_000_000L / RATE
                    val actual = nowUs - chunkUs
                    if (actual - expected > 150_000) baseUs += (actual - expected)
                }
                val ptsUs = baseUs + total * 1_000_000L / RATE
                total += samplesInChunk
                lastPts = ptsUs + chunkUs

                var peak = 0
                var i = 0
                while (i + 1 < n) {
                    val s = ((buf[i + 1].toInt() shl 8) or (buf[i].toInt() and 0xFF)).toShort().toInt()
                    val a = if (s < 0) -s else s
                    if (a > peak) peak = a
                    i += 2
                }

                // уровень на экране, не чаще 7 раз в секунду
                val nowMs = SystemClock.elapsedRealtime()
                if (nowMs - lastUi > 150) {
                    lastUi = nowMs
                    AudioStatus.level = sqrt((peak / 32768f).coerceIn(0f, 1f))
                }

                // детектор тишины (нулевой сигнал)
                val chunkMs = chunkUs / 1000
                if (peak <= 1) {
                    zeroMs += chunkMs
                } else {
                    if (silent) {
                        RecLog.log("Микрофон: звук вернулся, тишина длилась ${(nowMs - silentAt) / 1000} с")
                        AudioStatus.text = "Микрофон: работает"
                    }
                    silent = false
                    zeroMs = 0
                }
                if (!silent && zeroMs >= 2000) {
                    silent = true
                    silentAt = nowMs - zeroMs
                    RecLog.log(
                        "Микрофон: ТИШИНА (сплошные нули) уже ${zeroMs / 1000} с. " +
                            "Звонок: ${CallWatcher.name()}. Источник: «${SOURCES[srcIdx].second}»"
                    )
                    AudioStatus.text = "Микрофон: ТИШИНА (возможно, заглушён системой)"
                }

                // смена источника во время звонка
                val call = CallWatcher.state
                if (prevCall == TelephonyManager.CALL_STATE_IDLE && call != TelephonyManager.CALL_STATE_IDLE) {
                    tried.clear()
                    tried.add(srcIdx)
                    exhausted = false
                }
                var switchTo = -1
                if (call != TelephonyManager.CALL_STATE_IDLE && zeroMs >= 3000 && !exhausted) {
                    val next = SOURCES.indices.firstOrNull { it !in tried }
                    if (next == null) {
                        exhausted = true
                        RecLog.log("Микрофон: все источники звука заглушены системой на время звонка")
                    } else {
                        switchTo = next
                    }
                } else if (prevCall != TelephonyManager.CALL_STATE_IDLE && call == TelephonyManager.CALL_STATE_IDLE) {
                    tried.clear()
                    exhausted = false
                    val pref = prefSource.coerceIn(0, SOURCES.size - 1)
                    if (srcIdx != pref) switchTo = pref
                }
                prevCall = call

                if (switchTo >= 0) {
                    val newRec = openRecord(switchTo)
                    if (newRec != null) {
                        try { cur.stop() } catch (_: Exception) {}
                        cur.release()
                        cur = newRec
                        rec = newRec
                        newRec.startRecording()
                        srcIdx = switchTo
                        tried.add(srcIdx)
                        baseUs = -1L
                        zeroMs = 0
                        RecLog.log("Микрофон: переключил источник на «${SOURCES[srcIdx].second}»")
                    } else {
                        tried.add(switchTo)
                    }
                    continue
                }

                feed(enc, buf, n, ptsUs)
                drain(enc)
            }

            // завершение потока
            val idx = enc.dequeueInputBuffer(50_000)
            if (idx >= 0) enc.queueInputBuffer(idx, 0, 0, lastPts, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
            drain(enc, untilEos = true)
        } catch (e: Exception) {
            RecLog.log("Микрофон: ошибка: ${e.message}")
            writers.forEach { it.dropAudio() }
        } finally {
            try { rec?.stop() } catch (_: Exception) {}
            try { rec?.release() } catch (_: Exception) {}
            try { enc?.stop() } catch (_: Exception) {}
            try { enc?.release() } catch (_: Exception) {}
            AudioStatus.level = 0f
            if (!failed) AudioStatus.text = ""
            RecLog.log("Микрофон: остановлен")
        }
    }

    private fun feed(enc: MediaCodec, data: ByteArray, n: Int, ptsUs: Long) {
        var off = 0
        var tries = 0
        while (off < n) {
            val idx = enc.dequeueInputBuffer(20_000)
            if (idx < 0) {
                drain(enc)
                if (++tries > 10) return
                continue
            }
            val ib = enc.getInputBuffer(idx) ?: return
            ib.clear()
            val len = minOf(n - off, ib.capacity())
            ib.put(data, off, len)
            val chunkPts = ptsUs + (off / 2) * 1_000_000L / RATE
            enc.queueInputBuffer(idx, 0, len, chunkPts, 0)
            off += len
        }
    }

    private fun drain(enc: MediaCodec, untilEos: Boolean = false) {
        val info = MediaCodec.BufferInfo()
        var empty = 0
        while (true) {
            val i = enc.dequeueOutputBuffer(info, if (untilEos) 50_000 else 0)
            if (i == MediaCodec.INFO_TRY_AGAIN_LATER) {
                if (!untilEos || ++empty > 20) return
            } else if (i == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                val f = enc.outputFormat
                outFormat = f
                writers.forEach { it.setAudioFormat(f) }
            } else if (i >= 0) {
                val ob = enc.getOutputBuffer(i)
                val isConfig = (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0
                if (ob != null && info.size > 0 && !isConfig) writers.forEach { it.writeAudio(ob, info) }
                enc.releaseOutputBuffer(i, false)
                if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) return
            }
        }
    }

    companion object {
        const val RATE = 44100

        /** Источники звука: сначала выбранный, при звонке пробуются остальные. */
        val SOURCES: List<Pair<Int, String>> = listOf(
            MediaRecorder.AudioSource.MIC to "микрофон",
            MediaRecorder.AudioSource.VOICE_RECOGNITION to "распознавание речи",
            MediaRecorder.AudioSource.CAMCORDER to "камкордер",
            MediaRecorder.AudioSource.UNPROCESSED to "без обработки"
        )
    }
}
