package com.example.phonelock

import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageFormat
import android.graphics.Matrix
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CaptureRequest
import android.media.ExifInterface
import android.media.ImageReader
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.provider.MediaStore
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Снимает один кадр фронтальной камерой в фоне, без интерфейса, и сохраняет
 * в галерею (Pictures/PhoneLock) с меткой времени. Используется, когда кто-то
 * включает экран телефона — это момент попытки доступа, до ввода графического
 * ключа. Android не даёт сторонним приложениям узнать о НЕВЕРНОМ вводе ключа
 * на системном экране блокировки без спецправ, поэтому ловим именно включение
 * экрана — ближайший доступный сигнал.
 */
object CameraCapture {

    fun hasPermission(context: Context): Boolean =
        ContextCompat.checkSelfPermission(context, android.Manifest.permission.CAMERA) ==
            PackageManager.PERMISSION_GRANTED

    fun capture(context: Context) {
        if (!hasPermission(context)) return

        val thread = HandlerThread("phonelock-cam").apply { start() }
        val handler = Handler(thread.looper)
        val manager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager

        try {
            val frontId = manager.cameraIdList.firstOrNull {
                manager.getCameraCharacteristics(it)
                    .get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_FRONT
            } ?: manager.cameraIdList.firstOrNull() ?: return

            val chars = manager.getCameraCharacteristics(frontId)
            val sizes = chars.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
                ?.getOutputSizes(ImageFormat.JPEG)
            val size = sizes?.minByOrNull { it.width.toLong() * it.height } ?: return
            // Настоящий угол поворота матрицы этой камеры (обычно 90 или 270 у
            // фронталки) — нужен, чтобы камера сама записала в JPEG правильный
            // поворот, а не гадать число вручную.
            val sensorOrientation = chars.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 0

            val reader = ImageReader.newInstance(size.width, size.height, ImageFormat.JPEG, 1)
            reader.setOnImageAvailableListener({ r ->
                val image = r.acquireLatestImage()
                if (image != null) {
                    val buffer = image.planes[0].buffer
                    val bytes = ByteArray(buffer.remaining())
                    buffer.get(bytes)
                    image.close()
                    save(context, bytes)
                }
            }, handler)

            manager.openCamera(frontId, object : CameraDevice.StateCallback() {
                override fun onOpened(device: CameraDevice) {
                    try {
                        val requestBuilder =
                            device.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE)
                        requestBuilder.addTarget(reader.surface)
                        // Телефон при съёмке всегда в обычной портретной
                        // ориентации (экран только что включили), поэтому
                        // поворот устройства считаем нулевым.
                        requestBuilder.set(CaptureRequest.JPEG_ORIENTATION, sensorOrientation)
                        device.createCaptureSession(
                            listOf(reader.surface),
                            object : CameraCaptureSession.StateCallback() {
                                override fun onConfigured(session: CameraCaptureSession) {
                                    session.capture(requestBuilder.build(), null, handler)
                                }

                                override fun onConfigureFailed(session: CameraCaptureSession) {
                                    cleanup(device, reader, thread)
                                }
                            },
                            handler
                        )
                        // Закрыть камеру чуть позже, дав кадру дойти до слушателя
                        handler.postDelayed({ cleanup(device, reader, thread) }, 1500)
                    } catch (e: Throwable) {
                        cleanup(device, reader, thread)
                    }
                }

                override fun onDisconnected(device: CameraDevice) = cleanup(device, reader, thread)
                override fun onError(device: CameraDevice, error: Int) =
                    cleanup(device, reader, thread)
            }, handler)
        } catch (e: Throwable) {
            thread.quitSafely()
        }
    }

    private fun cleanup(device: CameraDevice?, reader: ImageReader, thread: HandlerThread) {
        try { device?.close() } catch (_: Throwable) {}
        try { reader.close() } catch (_: Throwable) {}
        thread.quitSafely()
    }

    /**
     * Камера записывает в EXIF снимка, на сколько градусов его нужно
     * повернуть, чтобы он стоял ровно (угол зависит от того, как физически
     * вклеена матрица камеры в конкретном телефоне — у фронталок обычно 90
     * или 270). Читаем этот угол и поворачиваем по нему, а не наугад.
     */
    private fun fixOrientation(jpeg: ByteArray): ByteArray {
        return try {
            val exif = ExifInterface(java.io.ByteArrayInputStream(jpeg))
            val tag = exif.getAttributeInt(
                ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL
            )
            val degrees = when (tag) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
            if (degrees == 0f) return jpeg
            val original = BitmapFactory.decodeByteArray(jpeg, 0, jpeg.size) ?: return jpeg
            val matrix = Matrix().apply { postRotate(degrees) }
            val rotated = Bitmap.createBitmap(
                original, 0, 0, original.width, original.height, matrix, true
            )
            val out = java.io.ByteArrayOutputStream()
            rotated.compress(Bitmap.CompressFormat.JPEG, 92, out)
            original.recycle()
            rotated.recycle()
            out.toByteArray()
        } catch (e: Throwable) {
            jpeg
        }
    }

    private fun save(context: Context, jpegRaw: ByteArray) {
        val jpeg = fixOrientation(jpegRaw)
        val name = "phonelock_" +
            SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date()) + ".jpg"
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                val values = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, name)
                    put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                    put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/PhoneLock")
                }
                val uri = context.contentResolver.insert(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values
                ) ?: return
                context.contentResolver.openOutputStream(uri)?.use { it.write(jpeg) }
            } else {
                val dir = context.getExternalFilesDir("PhoneLock") ?: return
                dir.mkdirs()
                java.io.File(dir, name).writeBytes(jpeg)
            }
            val time = SimpleDateFormat("dd.MM HH:mm:ss", Locale.getDefault()).format(Date())
            Prefs.noteCapturedPhoto(context, time)
        } catch (e: Throwable) {
            e.printStackTrace()
        }
    }
}
