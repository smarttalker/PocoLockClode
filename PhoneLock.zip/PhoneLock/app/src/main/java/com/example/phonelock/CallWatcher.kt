package com.example.phonelock

import android.content.Context
import android.os.Build
import android.telephony.PhoneStateListener
import android.telephony.TelephonyCallback
import android.telephony.TelephonyManager

/** Следит за состоянием звонка и записывает переходы в журнал (нужно разрешение READ_PHONE_STATE). */
object CallWatcher {
    @Volatile
    var state: Int = TelephonyManager.CALL_STATE_IDLE
        private set

    private var callback: Any? = null
    private var legacy: Any? = null

    fun name(s: Int = state): String = when (s) {
        TelephonyManager.CALL_STATE_RINGING -> "входящий вызов"
        TelephonyManager.CALL_STATE_OFFHOOK -> "идёт разговор или набор"
        else -> "нет звонка"
    }

    private fun set(s: Int) {
        if (s == state) return
        state = s
        RecLog.log("Звонок: ${name(s)}")
    }

    fun start(ctx: Context) {
        state = TelephonyManager.CALL_STATE_IDLE
        try {
            val tm = ctx.getSystemService(TelephonyManager::class.java)
            if (Build.VERSION.SDK_INT >= 31) {
                val cb = object : TelephonyCallback(), TelephonyCallback.CallStateListener {
                    override fun onCallStateChanged(state: Int) {
                        set(state)
                    }
                }
                callback = cb
                tm.registerTelephonyCallback(ctx.mainExecutor, cb)
            } else {
                @Suppress("DEPRECATION")
                val l = object : PhoneStateListener() {
                    @Deprecated("Deprecated in Java")
                    override fun onCallStateChanged(state: Int, phoneNumber: String?) {
                        set(state)
                    }
                }
                legacy = l
                @Suppress("DEPRECATION")
                tm.listen(l, PhoneStateListener.LISTEN_CALL_STATE)
            }
        } catch (e: Exception) {
            RecLog.log("Слежение за звонками недоступно: ${e.message}")
        }
    }

    fun stop(ctx: Context) {
        try {
            val tm = ctx.getSystemService(TelephonyManager::class.java)
            if (Build.VERSION.SDK_INT >= 31) {
                (callback as? TelephonyCallback)?.let { tm.unregisterTelephonyCallback(it) }
            } else {
                @Suppress("DEPRECATION")
                (legacy as? PhoneStateListener)?.let { tm.listen(it, PhoneStateListener.LISTEN_NONE) }
            }
        } catch (_: Exception) {
        }
        callback = null
        legacy = null
        state = TelephonyManager.CALL_STATE_IDLE
    }
}
