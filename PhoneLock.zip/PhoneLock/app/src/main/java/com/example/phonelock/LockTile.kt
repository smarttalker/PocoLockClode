package com.example.phonelock

import android.graphics.drawable.Icon
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/**
 * Плитка в шторке уведомлений, честно подписанная «PhoneLock» — никакой маскировки под
 * другие системные переключатели. Нажатие сразу блокирует экран и начинает запись —
 * быстрее, чем открывать приложение, при этом ничего не притворяется другой функцией.
 */
class LockTile : TileService() {

    override fun onStartListening() {
        super.onStartListening()
        val tile = qsTile
        if (tile != null) {
            tile.label = "PhoneLock"
            tile.contentDescription = "Блокировка и экстренная запись"
            tile.icon = Icon.createWithResource(this, R.drawable.ic_lock)
            tile.state = Tile.STATE_INACTIVE
            tile.updateTile()
        }
    }

    override fun onClick() {
        super.onClick()
        LockAction.run(this, record = true)
    }
}
