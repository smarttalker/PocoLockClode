package com.example.phonelock

import java.io.ByteArrayOutputStream
import java.io.DataOutputStream
import java.io.OutputStream
import java.nio.ByteBuffer

/**
 * Пишет фрагментированный MP4 (fMP4): заголовок сразу, потом кусочки по ~1 секунде.
 * В отличие от обычного MP4, такой файл остаётся читаемым, даже если телефон выключили или разбили
 * посреди записи: потеряется не больше последней секунды.
 * Не зависит от Android, поэтому проверяется обычными средствами на компьютере.
 */
class Fmp4Muxer(
    private val out: OutputStream,
    private val onFlushed: () -> Unit = {},
    private val fragmentUs: Long = 1_000_000L
) {
    private class Sample(val data: ByteArray, val ptsUs: Long, val key: Boolean)

    private class Track(
        val id: Int,
        val isVideo: Boolean,
        val timescale: Int,
        val config: ByteArray,
        val width: Int,
        val height: Int,
        val channels: Int
    ) {
        val pending = ArrayList<Sample>()
        var lastDur = 0L
        var lastTick = -1L
        var nextBaseTick = -1L
    }

    private val tracks = ArrayList<Track>()
    private var started = false
    private var seq = 1
    private var lastFlushUs = Long.MIN_VALUE

    /** sps/pps без стартовых кодов. Возвращает номер дорожки. */
    fun addVideoTrack(sps: ByteArray, pps: ByteArray, width: Int, height: Int): Int {
        check(!started)
        val avcc = ByteArrayOutputStream()
        DataOutputStream(avcc).apply {
            writeByte(1); writeByte(sps[1].toInt()); writeByte(sps[2].toInt()); writeByte(sps[3].toInt())
            writeByte(0xFF); writeByte(0xE1)
            writeShort(sps.size); write(sps)
            writeByte(1)
            writeShort(pps.size); write(pps)
        }
        tracks += Track(tracks.size + 1, true, 90000, avcc.toByteArray(), width, height, 0)
        return tracks.size - 1
    }

    /** asc - AudioSpecificConfig из AAC-кодека. */
    fun addAudioTrack(asc: ByteArray, sampleRate: Int, channels: Int): Int {
        check(!started)
        tracks += Track(tracks.size + 1, false, sampleRate, asc, 0, 0, channels)
        return tracks.size - 1
    }

    fun start() {
        check(!started)
        started = true
        out.write(ftyp())
        out.write(moov())
        out.flush()
        onFlushed()
    }

    fun writeSample(track: Int, data: ByteBuffer, ptsUs: Long, key: Boolean) {
        if (!started) return
        val t = tracks[track]
        val bytes = ByteArray(data.remaining())
        data.get(bytes)
        val payload = if (t.isVideo) annexBToAvcc(bytes) else bytes
        t.pending += Sample(payload, ptsUs, key)
        if (lastFlushUs == Long.MIN_VALUE) lastFlushUs = ptsUs
        if (ptsUs - lastFlushUs >= fragmentUs) {
            flush(false)
            lastFlushUs = ptsUs
        }
    }

    /** Дописывает остаток и закрывает поток. */
    fun finish() {
        if (!started) return
        flush(true)
        try { out.flush() } catch (_: Exception) {}
    }

    // ---------- фрагменты ----------

    private fun flush(final: Boolean) {
        var wrote = false
        for (t in tracks) {
            val list = t.pending
            if (list.isEmpty()) continue
            val emit = if (final) list.size else list.size - 1
            if (emit <= 0) continue
            val ticks = LongArray(emit + 1)
            for (i in 0 until emit) ticks[i] = list[i].ptsUs * t.timescale / 1_000_000L
            val hasNext = emit < list.size
            ticks[emit] = if (hasNext) list[emit].ptsUs * t.timescale / 1_000_000L else -1L
            val durs = LongArray(emit)
            for (i in 0 until emit) {
                durs[i] = if (i + 1 < emit) ticks[i + 1] - ticks[i]
                else if (hasNext) ticks[emit] - ticks[i]
                else if (t.lastDur > 0) t.lastDur else 1L
                if (durs[i] <= 0) durs[i] = 1L
            }
            // непрерывность: начало фрагмента = конец предыдущего
            val base = if (t.nextBaseTick >= 0 && Math.abs(t.nextBaseTick - ticks[0]) <= t.timescale / 50) t.nextBaseTick else ticks[0]
            t.lastDur = durs[emit - 1]
            t.nextBaseTick = base + durs.sum()
            val samples = list.subList(0, emit).toList()
            writeFragment(t, base, durs, samples)
            list.subList(0, emit).clear()
            wrote = true
        }
        if (wrote) {
            try { out.flush() } catch (_: Exception) {}
            onFlushed()
        }
    }

    private fun writeFragment(t: Track, baseTick: Long, durs: LongArray, samples: List<Sample>) {
        val moofNoOffset = moof(t, baseTick, durs, samples, 0)
        val moofBytes = moof(t, baseTick, durs, samples, moofNoOffset.size + 8)
        var mdatSize = 8L
        for (s in samples) mdatSize += s.data.size
        val hdr = ByteBuffer.allocate(8)
        hdr.putInt(mdatSize.toInt()).put("mdat".toByteArray(Charsets.US_ASCII))
        out.write(moofBytes)
        out.write(hdr.array())
        for (s in samples) out.write(s.data)
        seq++
    }

    private fun moof(t: Track, baseTick: Long, durs: LongArray, samples: List<Sample>, dataOffset: Int): ByteArray {
        val mfhd = box("mfhd") { writeInt(0); writeInt(seq) }
        val tfhd = box("tfhd") { writeInt(0x020000); writeInt(t.id) }
        val tfdt = box("tfdt") { writeInt(0x01000000); writeLong(baseTick) }
        val trun = box("trun") {
            writeInt(0x000701)
            writeInt(samples.size)
            writeInt(dataOffset)
            for (i in samples.indices) {
                writeInt(durs[i].toInt())
                writeInt(samples[i].data.size)
                writeInt(
                    if (!t.isVideo || samples[i].key) 0x02000000 else 0x01010000
                )
            }
        }
        val traf = box("traf") { write(tfhd); write(tfdt); write(trun) }
        val r = box("moof") { write(mfhd); write(traf) }
        return r
    }

    // ---------- заголовок ----------

    private fun ftyp(): ByteArray = box("ftyp") {
        write("iso5".toByteArray()); writeInt(512)
        write("iso5".toByteArray()); write("iso6".toByteArray()); write("avc1".toByteArray()); write("mp41".toByteArray())
    }

    private fun matrix(d: DataOutputStream) {
        d.writeInt(0x00010000); d.writeInt(0); d.writeInt(0)
        d.writeInt(0); d.writeInt(0x00010000); d.writeInt(0)
        d.writeInt(0); d.writeInt(0); d.writeInt(0x40000000)
    }

    private fun moov(): ByteArray {
        val mvhd = box("mvhd") {
            writeInt(0); writeInt(0); writeInt(0)
            writeInt(1000); writeInt(0)
            writeInt(0x00010000); writeShort(0x0100); writeShort(0); writeInt(0); writeInt(0)
            matrix(this)
            for (i in 0 until 6) writeInt(0)
            writeInt(tracks.size + 1)
        }
        val mvex = box("mvex") {
            for (t in tracks) write(box("trex") {
                writeInt(0); writeInt(t.id); writeInt(1); writeInt(0); writeInt(0); writeInt(0)
            })
        }
        return box("moov") {
            write(mvhd)
            for (t in tracks) write(trak(t))
            write(mvex)
        }
    }

    private fun trak(t: Track): ByteArray {
        val tkhd = box("tkhd") {
            writeInt(0x00000003)
            writeInt(0); writeInt(0); writeInt(t.id); writeInt(0); writeInt(0)
            writeInt(0); writeInt(0)
            writeShort(0); writeShort(0)
            writeShort(if (t.isVideo) 0 else 0x0100); writeShort(0)
            matrix(this)
            writeInt(t.width shl 16); writeInt(t.height shl 16)
        }
        val mdhd = box("mdhd") {
            writeInt(0); writeInt(0); writeInt(0); writeInt(t.timescale); writeInt(0)
            writeShort(0x55C4); writeShort(0)
        }
        val hdlr = box("hdlr") {
            writeInt(0); writeInt(0)
            write((if (t.isVideo) "vide" else "soun").toByteArray())
            writeInt(0); writeInt(0); writeInt(0)
            write((if (t.isVideo) "Video" else "Audio").toByteArray()); writeByte(0)
        }
        val dinf = box("dinf") {
            write(box("dref") { writeInt(0); writeInt(1); write(box("url ") { writeInt(1) }) })
        }
        val sampleEntry = if (t.isVideo) avc1(t) else mp4a(t)
        val stbl = box("stbl") {
            write(box("stsd") { writeInt(0); writeInt(1); write(sampleEntry) })
            write(box("stts") { writeInt(0); writeInt(0) })
            write(box("stsc") { writeInt(0); writeInt(0) })
            write(box("stsz") { writeInt(0); writeInt(0); writeInt(0) })
            write(box("stco") { writeInt(0); writeInt(0) })
        }
        val minf = box("minf") {
            if (t.isVideo) write(box("vmhd") { writeInt(1); writeInt(0); writeInt(0) })
            else write(box("smhd") { writeInt(0); writeInt(0) })
            write(dinf)
            write(stbl)
        }
        val mdia = box("mdia") { write(mdhd); write(hdlr); write(minf) }
        return box("trak") { write(tkhd); write(mdia) }
    }

    private fun avc1(t: Track): ByteArray = box("avc1") {
        for (i in 0 until 6) writeByte(0)
        writeShort(1)
        writeShort(0); writeShort(0)
        for (i in 0 until 3) writeInt(0)
        writeShort(t.width); writeShort(t.height)
        writeInt(0x00480000); writeInt(0x00480000)
        writeInt(0); writeShort(1)
        for (i in 0 until 32) writeByte(0)
        writeShort(0x0018); writeShort(0xFFFF)
        write(box("avcC") { write(t.config) })
    }

    private fun mp4a(t: Track): ByteArray = box("mp4a") {
        for (i in 0 until 6) writeByte(0)
        writeShort(1)
        writeInt(0); writeInt(0)
        writeShort(t.channels); writeShort(16)
        writeShort(0); writeShort(0)
        writeInt(t.timescale shl 16)
        write(box("esds") {
            writeInt(0)
            val dsi = t.config
            val dcd = ByteArrayOutputStream()
            DataOutputStream(dcd).apply {
                writeByte(0x40); writeByte(0x15); writeByte(0); writeShort(0)
                writeInt(0); writeInt(0)
                writeByte(0x05); writeByte(dsi.size); write(dsi)
            }
            val es = ByteArrayOutputStream()
            DataOutputStream(es).apply {
                writeShort(t.id); writeByte(0)
                writeByte(0x04); writeByte(dcd.size()); write(dcd.toByteArray())
                writeByte(0x06); writeByte(1); writeByte(2)
            }
            writeByte(0x03); writeByte(es.size()); write(es.toByteArray())
        })
    }

    private fun box(type: String, body: DataOutputStream.() -> Unit): ByteArray {
        val bos = ByteArrayOutputStream()
        val d = DataOutputStream(bos)
        d.body()
        val payload = bos.toByteArray()
        val res = ByteBuffer.allocate(8 + payload.size)
        res.putInt(8 + payload.size)
        res.put(type.toByteArray(Charsets.ISO_8859_1))
        res.put(payload)
        return res.array()
    }

    companion object {
        /** Разбивает поток H.264 со стартовыми кодами на NAL-единицы (без стартовых кодов). */
        fun splitAnnexB(b: ByteArray): List<ByteArray> {
            val res = ArrayList<ByteArray>()
            var i = 0
            var start = -1
            while (i + 2 < b.size) {
                if (b[i].toInt() == 0 && b[i + 1].toInt() == 0 && b[i + 2].toInt() == 1) {
                    if (start >= 0) {
                        var end = i
                        if (end > start && b[end - 1].toInt() == 0) end--
                        res += b.copyOfRange(start, end)
                    }
                    start = i + 3
                    i += 3
                } else i++
            }
            if (start >= 0 && start < b.size) res += b.copyOfRange(start, b.size)
            return res
        }

        fun annexBToAvcc(b: ByteArray): ByteArray {
            val nals = splitAnnexB(b)
            val out = ByteArrayOutputStream(b.size + 8)
            val d = DataOutputStream(out)
            for (n in nals) {
                if (n.isEmpty()) continue
                val type = n[0].toInt() and 0x1F
                if (type == 7 || type == 8 || type == 9) continue // SPS/PPS лежат в заголовке
                d.writeInt(n.size)
                d.write(n)
            }
            return out.toByteArray()
        }
    }
}
