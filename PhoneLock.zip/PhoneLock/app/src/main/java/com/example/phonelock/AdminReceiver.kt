package com.example.phonelock

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Device Admin нужен для двух вещей: мгновенной блокировки экрана (force-lock) и
 * честного сигнала «кто-то ввёл неверный код/рисунок на системном экране блокировки»
 * (onPasswordFailed — он приходит только если ниже, в device_admin.xml, включена
 * политика watch-login). Это штатный публичный API Android, которым пользуются
 * обычные антивор-приложения — слежки за системой в обход этого API тут нет.
 */
class AdminReceiver : DeviceAdminReceiver() {

    private fun now() = SimpleDateFormat("dd.MM HH:mm:ss", Locale.getDefault()).format(Date())

    override fun onPasswordFailed(context: Context, intent: Intent) {
        super.onPasswordFailed(context, intent)
        val streak = Prefs.wrongAttemptStreak(context) + 1
        Prefs.setWrongAttemptStreak(context, streak)
        Prefs.setLastAction(context, "${now()}\nНеверный код на экране блокировки (подряд: $streak)")

        if (Prefs.photoOnWrongPassword(context) && CameraCapture.hasPermission(context)) {
            CameraCapture.capture(context)
        }

        val threshold = Prefs.recordAfterWrongAttempts(context)
        if (threshold > 0 && streak >= threshold) {
            try {
                RecordingService.start(context, 0, bothCameras = true)
            } catch (e: Throwable) {
                e.printStackTrace()
            }
        }
    }

    override fun onPasswordSucceeded(context: Context, intent: Intent) {
        super.onPasswordSucceeded(context, intent)
        Prefs.setWrongAttemptStreak(context, 0)
        UnlockService.restoreBiometrics(context)
    }
}
