package com.example.phonelock

import android.app.Activity
import android.os.Bundle

/** Невидимая activity для пункта «Остановить» в меню долгого нажатия на иконку. */
class StopActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        RecordingService.stop(this)
        finish()
    }
}
