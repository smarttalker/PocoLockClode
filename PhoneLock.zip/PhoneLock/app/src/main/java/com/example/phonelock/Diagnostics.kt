package com.example.phonelock

import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.ImageFormat
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CameraMetadata
import android.hardware.camera2.params.OutputConfiguration
import android.hardware.camera2.params.SessionConfiguration
import android.media.ImageReader
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executor
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference

/**
 * Проверка: умеет ли этот телефон держать две камеры одновременно.
 * Выводит данные о телефоне и камерах, затем пробует открыть и запустить каждую пару камер.
 * Запускать только когда запись не идёт.
 */
object Diagnostics {
    var running by mutableStateOf(false)
        private set

    fun run(ctx: Context) {
        if (running) return
        running = true
        val app = ctx.applicationContext
        Thread {
            try {
                runInternal(app)
            } catch (e: Exception) {
                RecLog.log("Диагностика: ошибка ${e.message}")
            } finally {
                running = false
            }
        }.start()
    }

    private class OpenResult {
        @Volatile var device: CameraDevice? = null
        @Volatile var error: Int = 0
        @Volatile var lost: Boolean = false
    }

    private class Sess(val ok: Boolean, private val reader: ImageReader?, private val session: CameraCaptureSession?) {
        fun close() {
            try { session?.close() } catch (_: Exception) {}
            try { reader?.close() } catch (_: Exception) {}
        }
    }

    private fun errName(code: Int): String = when (code) {
        1 -> "камера занята"
        2 -> "достигнут предел одновременно открытых камер"
        3 -> "камера отключена политикой"
        4 -> "ошибка устройства камеры"
        5 -> "ошибка службы камеры"
        -1 -> "камера отключилась"
        -2 -> "исключение при открытии"
        -3 -> "не открылась за 5 секунд"
        else -> "код $code"
    }

    @SuppressLint("MissingPermission")
    private fun openSync(cm: CameraManager, id: String, handler: Handler): OpenResult {
        val res = OpenResult()
        val latch = CountDownLatch(1)
        try {
            cm.openCamera(id, object : CameraDevice.StateCallback() {
                override fun onOpened(d: CameraDevice) {
                    res.device = d
                    latch.countDown()
                }

                override fun onDisconnected(d: CameraDevice) {
                    if (res.device != null) res.lost = true else res.error = -1
                    d.close()
                    latch.countDown()
                }

                override fun onError(d: CameraDevice, e: Int) {
                    if (res.device != null) res.lost = true else res.error = e
                    d.close()
                    latch.countDown()
                }
            }, handler)
            if (!latch.await(5, TimeUnit.SECONDS)) res.error = -3
        } catch (e: Exception) {
            res.error = -2
        }
        return res
    }

    private fun startSession(cm: CameraManager, id: String, device: CameraDevice, handler: Handler): Sess {
        val chars = cm.getCameraCharacteristics(id)
        val map = chars.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP) ?: return Sess(false, null, null)
        val size = map.getOutputSizes(ImageFormat.YUV_420_888)?.minByOrNull { it.width * it.height }
            ?: return Sess(false, null, null)
        val reader = ImageReader.newInstance(size.width, size.height, ImageFormat.YUV_420_888, 2)
        val latch = CountDownLatch(1)
        val ok = AtomicBoolean(false)
        val ref = AtomicReference<CameraCaptureSession?>(null)
        try {
            val cfg = SessionConfiguration(
                SessionConfiguration.SESSION_REGULAR,
                listOf(OutputConfiguration(reader.surface)),
                Executor { handler.post(it) },
                object : CameraCaptureSession.StateCallback() {
                    override fun onConfigured(s: CameraCaptureSession) {
                        ref.set(s)
                        ok.set(true)
                        latch.countDown()
                    }

                    override fun onConfigureFailed(s: CameraCaptureSession) {
                        latch.countDown()
                    }
                }
            )
            device.createCaptureSession(cfg)
            latch.await(5, TimeUnit.SECONDS)
        } catch (_: Exception) {
        }
        return Sess(ok.get(), reader, ref.get())
    }

    private fun testPair(cm: CameraManager, a: String, b: String, handler: Handler) {
        val ra = openSync(cm, a, handler)
        val da = ra.device
        if (da == null) {
            RecLog.log("Пара $a+$b: первая не открылась (${errName(ra.error)})")
            return
        }
        val rb = openSync(cm, b, handler)
        val db = rb.device
        if (db == null) {
            RecLog.log("Пара $a+$b: вторая не открылась (${errName(rb.error)})")
            try { da.close() } catch (_: Exception) {}
            return
        }
        val sa = startSession(cm, a, da, handler)
        val sb = startSession(cm, b, db, handler)
        Thread.sleep(300)
        val alive = !ra.lost && !rb.lost
        if (sa.ok && sb.ok && alive) {
            RecLog.log("Пара $a+$b: ОБЕ РАБОТАЮТ ОДНОВРЕМЕННО")
        } else {
            RecLog.log("Пара $a+$b: открылись обе, но вместе не работают (сессии $a=${sa.ok} $b=${sb.ok}, одна из камер отключена=${!alive})")
        }
        sa.close()
        sb.close()
        try { da.close() } catch (_: Exception) {}
        try { db.close() } catch (_: Exception) {}
    }

    private fun runInternal(ctx: Context) {
        val cm = ctx.getSystemService(CameraManager::class.java)
        RecLog.log("Диагностика: ${Build.MANUFACTURER} ${Build.MODEL} (${Build.DEVICE}), Android ${Build.VERSION.RELEASE}, API ${Build.VERSION.SDK_INT}")
        RecLog.log("Сборка: ${Build.DISPLAY}")
        RecLog.log("Флаг системы camera.concurrent: ${ctx.packageManager.hasSystemFeature(PackageManager.FEATURE_CAMERA_CONCURRENT)}")

        val ids = cm.cameraIdList.toList()
        RecLog.log("Камеры, которые показывает система: ${ids.joinToString()}")
        for (id in ids) {
            val c = cm.getCameraCharacteristics(id)
            val facing = when (c.get(CameraCharacteristics.LENS_FACING)) {
                CameraCharacteristics.LENS_FACING_BACK -> "основная"
                CameraCharacteristics.LENS_FACING_FRONT -> "фронтальная"
                else -> "внешняя"
            }
            val level = when (c.get(CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL)) {
                CameraMetadata.INFO_SUPPORTED_HARDWARE_LEVEL_LEGACY -> "LEGACY"
                CameraMetadata.INFO_SUPPORTED_HARDWARE_LEVEL_LIMITED -> "LIMITED"
                CameraMetadata.INFO_SUPPORTED_HARDWARE_LEVEL_FULL -> "FULL"
                CameraMetadata.INFO_SUPPORTED_HARDWARE_LEVEL_3 -> "LEVEL_3"
                else -> "?"
            }
            val logical = c.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES)
                ?.contains(CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_LOGICAL_MULTI_CAMERA) == true
            val phys = c.physicalCameraIds.joinToString()
            RecLog.log("Камера $id: $facing, уровень $level, сенсор ${c.get(CameraCharacteristics.SENSOR_ORIENTATION)}°, составная=$logical, физические=[$phys]")
        }
        val sets = try { cm.concurrentCameraIds } catch (e: Exception) { emptySet() }
        RecLog.log("Пары, объявленные системой как одновременные: ${if (sets.isEmpty()) "нет" else sets.joinToString { it.joinToString("+") }}")

        val thread = HandlerThread("diag").also { it.start() }
        val handler = Handler(thread.looper)
        try {
            val list = ids.take(8)
            RecLog.log("Проверяю пары камер, подожди...")
            for (i in list.indices) {
                for (j in i + 1 until list.size) {
                    testPair(cm, list[i], list[j], handler)
                    Thread.sleep(500)
                }
            }
        } finally {
            thread.quitSafely()
        }
        RecLog.log("Диагностика завершена. Нажми «Скопировать журнал» и пришли мне текст.")
    }
}
